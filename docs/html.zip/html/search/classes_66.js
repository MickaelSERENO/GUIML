var searchData=
[
  ['frame',['Frame',['../classguiml_1_1_frame.html',1,'guiml']]]
];
